# SpaceX Falcon 9 Landing Prediction — IBM Data Science Capstone

## Files
- `SpaceX_Capstone_Analysis.ipynb`: reproducible run instructions.
- `spacex_analysis.py`: full pipeline for data checks, classification, metrics, confusion matrix, SQL outputs, and charts.
- `spacex_sql_queries.sql`: SQL queries executed by the analysis script.
- `spacex_dash_app.py`: interactive Plotly Dash dashboard source.
- `folium_launch_sites.html`: Folium map artifact.
- `Data Science Capstone Project Report.pdf` and `.pptx`: report and presentation.

## Run
1. Install dependencies: `pip install pandas numpy matplotlib scikit-learn plotly dash folium`.
2. Place the IBM course `dataset_part_2.csv` in this folder as `spacex_launch_data.csv`, or run with internet access so the script can download it.
3. Run `python spacex_analysis.py`.
4. Review `classification_metrics.csv`, `confusion_matrix.csv`, `sql_*.csv`, and charts under `assets/`.
5. Run `python spacex_dash_app.py` after the CSV is present. Capture a screenshot from the live app for the final submission.

## Important integrity note
The earlier report contained provisional classification scores from a different/uncertain target definition. They must not be presented as final. The updated script calculates metrics against the course dataset's `Class` target (1 = successful landing, 0 = unsuccessful) and writes the actual results when executed. The public dataset URL is used as a reproducibility fallback; an offline environment must provide the CSV locally.

## Repository
https://github.com/itsilger97-hub/IBM-SpaceX-Capstone

The local package has not been pushed to GitHub automatically. Upload these deliverables to the repository and verify that the repository URL opens before submitting.
