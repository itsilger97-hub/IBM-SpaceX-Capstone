"""
IBM Data Science Capstone — SpaceX Falcon 9 landing prediction.
Run: python spacex_analysis.py
Input: spacex_launch_data.csv (IBM course dataset_part_2.csv format).
If the CSV is absent, the script downloads the public course dataset.
"""
from pathlib import Path
import sqlite3
import urllib.request
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

ROOT = Path(__file__).resolve().parent
CSV = ROOT / "spacex_launch_data.csv"
DATA_URL = "https://raw.githubusercontent.com/adgsenpai/IBM-DataScience-SpaceX-Capstone/master/dataset_part_2.csv"
if not CSV.exists():
    print("Downloading the IBM course dataset...")
    urllib.request.urlretrieve(DATA_URL, CSV)

df = pd.read_csv(CSV)
print(f"Dataset shape: {df.shape}")
print("Missing values by column:")
print(df.isna().sum().to_string())

# Course dataset target is Class: 1 = successful landing, 0 = unsuccessful.
if "Class" in df.columns:
    y = pd.to_numeric(df["Class"], errors="coerce")
else:
    outcome_col = "Landing_Outcome" if "Landing_Outcome" in df.columns else "Outcome"
    successful = {"Success", "Success (drone ship)", "Success (ground pad)", "True ASDS", "True RTLS", "True Ocean"}
    y = df[outcome_col].astype(str).isin(successful).astype(int)

# Keep only predictors available before the landing result.
candidate = ["PayloadMass", "Orbit", "LaunchSite", "BoosterVersion", "Flights", "GridFins", "Reused", "Legs", "Block", "ReusedCount"]
candidate = [c for c in candidate if c in df.columns]
X = df[candidate].copy()
numeric = [c for c in X.columns if pd.api.types.is_numeric_dtype(X[c]) or X[c].nunique(dropna=True) > 15]
categorical = [c for c in X.columns if c not in numeric]
for c in numeric:
    X[c] = pd.to_numeric(X[c], errors="coerce")

numeric_pipe = Pipeline([("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler())])
categorical_pipe = Pipeline([("imputer", SimpleImputer(strategy="most_frequent")), ("onehot", OneHotEncoder(handle_unknown="ignore"))])
preprocess = ColumnTransformer([("num", numeric_pipe, numeric), ("cat", categorical_pipe, categorical)])

X_train, X_test, y_train, y_test = train_test_split(
    X, y.astype(int), test_size=0.2, random_state=42, stratify=y.astype(int)
)
models = {
    "Dummy baseline": DummyClassifier(strategy="most_frequent"),
    "Logistic Regression": LogisticRegression(max_iter=2000, random_state=42),
    "SVM (RBF)": SVC(kernel="rbf", random_state=42),
    "Decision Tree": DecisionTreeClassifier(max_depth=4, random_state=42),
    "Random Forest": RandomForestClassifier(n_estimators=300, min_samples_leaf=2, random_state=42, class_weight="balanced")
}
rows, fitted = [], {}
for name, model in models.items():
    pipe = Pipeline([("preprocess", preprocess), ("model", model)])
    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    rows.append({
        "Model": name,
        "Accuracy": accuracy_score(y_test, pred),
        "Precision": precision_score(y_test, pred, zero_division=0),
        "Recall": recall_score(y_test, pred, zero_division=0),
        "F1": f1_score(y_test, pred, zero_division=0)
    })
    fitted[name] = (pipe, pred)

metrics = pd.DataFrame(rows).sort_values("F1", ascending=False)
metrics.to_csv(ROOT / "classification_metrics.csv", index=False)
print("\nClassification metrics (holdout, random_state=42):")
print(metrics.to_string(index=False, formatters={c: (lambda x: f"{x:.3f}") for c in ["Accuracy","Precision","Recall","F1"]}))

best_name = metrics.iloc[0]["Model"]
best_pipe, best_pred = fitted[best_name]
labels = [0, 1]
cm = confusion_matrix(y_test, best_pred, labels=labels)
pd.DataFrame(cm, index=["Actual 0","Actual 1"], columns=["Predicted 0","Predicted 1"]).to_csv(ROOT / "confusion_matrix.csv")
print(f"\nSelected by F1: {best_name}")
print("Confusion matrix (rows=actual, columns=predicted):")
print(cm)
print(classification_report(y_test, best_pred, zero_division=0))

# SQL results are generated from the same data file used by the model.
con = sqlite3.connect(":memory:")
df.to_sql("SPACEXTBL", con, index=False, if_exists="replace")
queries = {
 "launch_site_counts": "SELECT LaunchSite, COUNT(*) AS Total_Launches FROM SPACEXTBL GROUP BY LaunchSite ORDER BY Total_Launches DESC",
 "orbit_counts": "SELECT Orbit, COUNT(*) AS Total_Launches FROM SPACEXTBL GROUP BY Orbit ORDER BY Total_Launches DESC",
 "payload_range": "SELECT MIN(PayloadMass) AS Min_Payload_kg, MAX(PayloadMass) AS Max_Payload_kg, ROUND(AVG(PayloadMass),1) AS Mean_Payload_kg FROM SPACEXTBL",
 "success_by_site": "SELECT LaunchSite, ROUND(AVG(Class)*100,1) AS Success_Rate_Pct, COUNT(*) AS N FROM SPACEXTBL GROUP BY LaunchSite ORDER BY Success_Rate_Pct DESC"
}
for name, sql in queries.items():
    out = pd.read_sql_query(sql, con)
    out.to_csv(ROOT / f"sql_{name}.csv", index=False)
    print(f"\nSQL: {name}\n{out.to_string(index=False)}")

# Evidence visuals generated from the same data.
plt.figure(figsize=(9, 5))
if "Class" in df:
    df["Class"].value_counts().sort_index().rename(index={0:"Unsuccessful",1:"Successful"}).plot(kind="bar")
else:
    pd.Series(y).value_counts().sort_index().rename(index={0:"Unsuccessful",1:"Successful"}).plot(kind="bar")
plt.title("Landing success class balance")
plt.xlabel("Landing class"); plt.ylabel("Launches"); plt.tight_layout()
plt.savefig(ROOT / "assets" / "class_balance_verified.png", dpi=180); plt.close()

plt.figure(figsize=(8, 4.5))
metrics.set_index("Model")[["Accuracy","Precision","Recall","F1"]].plot(kind="bar", ylim=(0,1), figsize=(9,5))
plt.title("Holdout classification metrics"); plt.ylabel("Score"); plt.xticks(rotation=20, ha="right")
plt.tight_layout(); plt.savefig(ROOT / "assets" / "classification_metrics_verified.png", dpi=180); plt.close()

print("\nFiles written: classification_metrics.csv, confusion_matrix.csv, sql_*.csv, and verified charts.")
