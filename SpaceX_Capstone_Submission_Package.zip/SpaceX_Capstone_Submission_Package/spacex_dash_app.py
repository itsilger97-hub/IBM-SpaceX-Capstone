import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html, Input, Output

df = pd.read_csv("spacex_launch_data.csv")
app = Dash(__name__)
sites = sorted(df["Launch_Site"].dropna().unique())
outcomes = sorted(df["Landing_Outcome"].dropna().unique())

app.layout = html.Div([
    html.H1("SpaceX Falcon 9 Launch Outcomes"),
    html.P("Explore the historical IBM course dataset."),
    html.Label("Launch site"),
    dcc.Dropdown(id="site-filter", options=[{"label":"All sites","value":"ALL"}] +
        [{"label":s,"value":s} for s in sites], value="ALL", clearable=False),
    html.Label("Landing outcome"),
    dcc.Dropdown(id="outcome-filter", options=[{"label":"All outcomes","value":"ALL"}] +
        [{"label":s,"value":s} for s in outcomes], value="ALL", clearable=False),
    html.Div(id="summary"),
    dcc.Graph(id="outcome-chart")
], style={"maxWidth":"1100px","margin":"30px auto","fontFamily":"Arial"})

@app.callback(
    Output("outcome-chart","figure"),
    Output("summary","children"),
    Input("site-filter","value"),
    Input("outcome-filter","value")
)
def update_dashboard(site, outcome):
    filtered = df.copy()
    if site != "ALL":
        filtered = filtered[filtered["Launch_Site"] == site]
    if outcome != "ALL":
        filtered = filtered[filtered["Landing_Outcome"] == outcome]
    counts = filtered["Landing_Outcome"].fillna("Unknown").value_counts().rename_axis("Landing_Outcome").reset_index(name="Count")
    fig = px.bar(counts, x="Landing_Outcome", y="Count", title="Landing outcomes in filtered data", color="Landing_Outcome")
    fig.update_layout(showlegend=False, xaxis_tickangle=-30)
    return fig, f"Records shown: {len(filtered)}"

if __name__ == "__main__":
    app.run(debug=True)
