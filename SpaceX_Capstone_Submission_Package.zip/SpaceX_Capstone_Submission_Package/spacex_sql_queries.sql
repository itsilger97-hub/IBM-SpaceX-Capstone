-- Run against the same CSV used for the model; table name: SPACEXTBL
SELECT LaunchSite, COUNT(*) AS Total_Launches
FROM SPACEXTBL
GROUP BY LaunchSite
ORDER BY Total_Launches DESC;

SELECT Orbit, COUNT(*) AS Total_Launches
FROM SPACEXTBL
GROUP BY Orbit
ORDER BY Total_Launches DESC;

SELECT MIN(PayloadMass) AS Min_Payload_kg,
       MAX(PayloadMass) AS Max_Payload_kg,
       ROUND(AVG(PayloadMass), 1) AS Mean_Payload_kg
FROM SPACEXTBL;

SELECT LaunchSite,
       ROUND(AVG(Class) * 100, 1) AS Success_Rate_Pct,
       COUNT(*) AS N
FROM SPACEXTBL
GROUP BY LaunchSite
ORDER BY Success_Rate_Pct DESC;
